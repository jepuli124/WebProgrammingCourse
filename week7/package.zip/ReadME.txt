Made by konsta jalkanen x104058

Arrows to move.
Space to chop wood.

Try collect logs as much as you can while dodging mildly misformed birds and very slimy slimes.
